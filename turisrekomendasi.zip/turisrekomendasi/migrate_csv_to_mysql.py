import pandas as pd
from sqlalchemy import create_engine

# Read the CSV
df = pd.read_csv('app/dataset.csv')

# Create SQLAlchemy engine (replace with your credentials)
engine = create_engine('mysql+pymysql://username:password@localhost:3306/your_database')

# Write to MySQL
df.to_sql('places', con=engine, if_exists='replace', index=False)