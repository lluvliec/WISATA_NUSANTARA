from sqlalchemy import create_engine
import pandas as pd
import sys # Import sys to handle potential errors

# Ganti dengan kredensial database kamu
user = 'root'
password = ''  # Ganti dengan password kamu (leave empty if no password)
host = 'localhost' # Or '127.0.0.1'
port = '3306'  # Default port MySQL
database = 'rekomendasi_wisata'
table_name = 'places' # Define the table name consistently

try:
    # Koneksi ke database MySQL menggunakan SQLAlchemy
    # Construct the connection string using the variables
    connection_string = f"mysql+pymysql://{user}:{password}@{host}:{port}/{database}"
    engine = create_engine(connection_string)

    # Verify connection (optional but recommended)
    with engine.connect() as connection:
        print("Successfully connected to the database.")

    # Membaca file CSV
    # Use the correct relative path if seed.py is in the 'app' directory
    # If seed.py is in the root 'turisrekomendasi' directory, use "app/dataset.csv"
    # If seed.py is in the 'app' directory, use "dataset.csv"
    csv_path = "dataset.csv" # Assuming seed.py is in the 'app' directory
    df = pd.read_csv(csv_path)
    print(f"Successfully read {len(df)} rows from {csv_path}")

    # Menyimpan data ke tabel, jika tabel sudah ada maka akan digantikan
    print(f"Writing data to table '{table_name}'...")
    # Use the defined table_name variable
    df.to_sql(table_name, con=engine, if_exists="replace", index=False)
    print(f"Data successfully written to table '{table_name}' in database '{database}'.")

    # Optional: Verify data insertion by reading back a few rows
    print(f"\nVerifying data insertion from table '{table_name}':")
    # Use the defined table_name variable in the query
    query = f"SELECT * FROM {table_name} LIMIT 5;"
    result = pd.read_sql(query, con=engine)

    # Menampilkan hasil query
    print(result)

except FileNotFoundError:
    print(f"Error: CSV file not found at '{csv_path}'. Make sure the path is correct relative to where you run the script.")
    sys.exit(1)
except ImportError:
    print("Error: Required libraries (SQLAlchemy, pandas, PyMySQL) not found.")
    print("Please install them using: pip install sqlalchemy pandas pymysql")
    sys.exit(1)
except Exception as e:
    print(f"An error occurred: {e}")
    print("Please check your database credentials, connection, and table structure.")
    sys.exit(1)
finally:
    # Dispose of the engine connection pool (good practice)
    if 'engine' in locals() and engine:
        engine.dispose()
        print("\nDatabase connection closed.")