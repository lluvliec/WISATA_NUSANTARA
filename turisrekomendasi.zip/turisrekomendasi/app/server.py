from fastapi import FastAPI, HTTPException
import joblib
import numpy as np
from pydantic import BaseModel
from typing import List
# Hapus import sqlite3 jika beralih ke MySQL
# import sqlite3
from sqlalchemy import create_engine, text # Import SQLAlchemy
import pandas as pd # Import pandas untuk read_sql
import sys
import os

# Import the module where HybridRecommender is defined
from app.recommender_module import HybridRecommender

# --- Konfigurasi Database (Contoh untuk MySQL, sesuaikan dengan setup Anda) ---
DB_USER = os.getenv('MYSQL_USER', 'root') # Sesuaikan dengan user Anda
DB_PASSWORD = os.getenv('MYSQL_PASSWORD', '') # Sesuaikan dengan password Anda
DB_HOST = os.getenv('MYSQL_HOST', 'localhost') # Atau 'host.docker.internal' jika server jalan di Docker & DB di host
DB_PORT = os.getenv('MYSQL_PORT', '3306')
DB_NAME = os.getenv('MYSQL_DATABASE', 'rekomendasi_wisata') # Nama database dari seed.py
TABLE_NAME = 'places' # Nama tabel dari seed.py

DATABASE_URL = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

try:
    engine = create_engine(DATABASE_URL)
    # Test connection
    with engine.connect() as connection:
        print("Successfully connected to the database.")
except Exception as e:
    print(f"Error connecting to database: {e}")
    sys.exit(1)

# --- Muat Model yang Sudah Dilatih ---
MODEL_PATH = 'app/hybrid_recommender.joblib'
try:
    model: HybridRecommender = joblib.load(MODEL_PATH)
    print(f"Model loaded successfully from {MODEL_PATH}")
    # Pastikan model memiliki atribut yang diperlukan (hasil dari .fit())
    if model.content_features is None or model.collab_matrix is None:
         print("Warning: Loaded model might not be fitted. Ensure it was trained and saved correctly.")
         # Anda mungkin ingin menghentikan server jika model tidak valid
         # sys.exit(1)
except FileNotFoundError:
    print(f"Error: Model file not found at {MODEL_PATH}")
    sys.exit(1)
except Exception as e:
    print(f"Error loading model: {e}")
    sys.exit(1)


app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "INI VERSI BARU! Recommendation API Ready."}

# --- Endpoint Rekomendasi yang Dimodifikasi ---
# Kita asumsikan ada cara memetakan user_id (misal: 101) ke user_idx (misal: 0, 1, 2, ...)
# Untuk contoh ini, kita anggap user_id adalah sama dengan user_idx (perlu disesuaikan)
@app.get("/rekomendasi/{user_id}")
def get_rekomendasi_for_user(user_id: int, k: int = 10): # Terima user_id dan jumlah rekomendasi (k)
    try:
        # TODO: Implementasi mapping user_id ke user_idx
        # Contoh sederhana (jika user_id = user_idx):
        user_idx = user_id
        # Validasi apakah user_idx ada dalam data model (jika memungkinkan)
        # Misalnya, cek apakah user_idx < len(model.collab_matrix)

        # 1. Dapatkan rekomendasi ID dari model
        recommended_place_ids = model.recommend(user_idx=user_idx, k=k)

        if not recommended_place_ids:
            return {"rekomendasi": []} # Kembalikan list kosong jika tidak ada rekomendasi

        # 2. Ambil detail tempat dari database berdasarkan ID yang direkomendasikan
        # Pastikan kolom yang dipilih sesuai dengan nama kolom di tabel 'places'
        # Contoh kolom: Place_Id, Place_Name, City, Category, Rating, Description, Price, Tags, Coordinate
        query = text(f"""
            SELECT Place_Id, Place_Name, City, Category, Rating, Description, Price, Tags, Coordinate
            FROM {TABLE_NAME}
            WHERE Place_Id IN :ids
        """)

        with engine.connect() as connection:
            # Fetch data using pandas for easier handling
            result_df = pd.read_sql(query, connection, params={'ids': tuple(recommended_place_ids)})

        # 3. Format hasil (urutkan sesuai urutan rekomendasi jika perlu)
        # Convert DataFrame to list of dicts
        hasil = result_df.to_dict(orient='records')

        # Optional: Reorder results based on model's recommendation order
        id_to_detail = {item['Place_Id']: item for item in hasil}
        ordered_hasil = [id_to_detail[pid] for pid in recommended_place_ids if pid in id_to_detail]

        return {"rekomendasi": ordered_hasil}

    except IndexError:
         # Jika user_idx di luar jangkauan data model
         raise HTTPException(status_code=404, detail=f"User index {user_idx} not found in model data.")
    except Exception as e:
        # Tangani error lain (misal: database error)
        print(f"Error during recommendation for user {user_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error while generating recommendations.")

# --- Tambahkan endpoint lain jika perlu ---