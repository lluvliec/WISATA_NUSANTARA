import pandas as pd
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, Text, Float, inspect
from sqlalchemy.exc import SQLAlchemyError
import sys
import time # Import time untuk delay
import os  # Untuk membaca environment variable jika perlu (opsional tapi bagus)

# --- Database Configuration ---
# Ambil dari environment variable Docker Compose, atau gunakan default
# Nama service 'db' akan diresolve oleh Docker Compose ke IP kontainer MySQL
DB_USER = os.getenv('MYSQL_USER', 'user_tourism') # Ganti default jika perlu
DB_PASSWORD = os.getenv('MYSQL_PASSWORD', 'apppwd123') # Ganti default jika perlu
DB_HOST = os.getenv('DB_HOST', 'db') # PENTING: Gunakan nama service 'db'
DB_PORT = os.getenv('DB_PORT', '3306')
DB_NAME = os.getenv('MYSQL_DATABASE', 'tourism_db') # Ganti default jika perlu

TABLE_NAME = 'places'
CSV_FILE_PATH = 'dataset.csv' # Path relatif terhadap working directory di container

# --- SQLAlchemy Setup ---
DATABASE_URL = f"mysql+mysqlconnector://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
# DATABASE_URL = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}" # jika pakai pymysql

# Tambahkan sedikit delay untuk memberi waktu DB siap (terutama saat pertama kali dibuat)
print("Menunggu database siap...")
time.sleep(15) # Tunggu 15 detik (sesuaikan jika perlu)

# Create engine
try:
    engine = create_engine(DATABASE_URL, echo=False)
    # Coba koneksi awal
    connection = engine.connect()
    print(f"Berhasil terhubung ke engine database '{DB_NAME}' di host '{DB_HOST}'")
    connection.close() # Tutup koneksi percobaan
except ImportError as e:
    print(f"Error: Driver database tidak ditemukan. Pastikan 'mysql-connector-python' atau 'pymysql' ada di requirements.txt. Detail: {e}")
    sys.exit(1)
except SQLAlchemyError as e:
    print(f"Error membuat atau menghubungkan ke engine database: {e}")
    print("Pastikan service database sudah berjalan dan kredensial benar.")
    sys.exit(1)
except Exception as e:
    print(f"Error tak terduga saat setup engine: {e}")
    sys.exit(1)


# --- Define Table Structure ---
metadata = MetaData()

places_table = Table(
    TABLE_NAME,
    metadata,
    Column('Place_Id', Integer, primary_key=True, autoincrement=False),
    Column('Place_Name', String(255), nullable=False),
    Column('Description', Text),
    Column('Category', String(100)),
    Column('City', String(100)),
    Column('Price', Integer),
    Column('Rating', Float),
    Column('Coordinate', Text),
    Column('Rating_Count', Integer),
    Column('Tags', Text)
)

# --- Create Table if it Doesn't Exist ---
try:
    inspector = inspect(engine)
    if not inspector.has_table(TABLE_NAME):
        print(f"Tabel '{TABLE_NAME}' tidak ada. Membuat tabel...")
        metadata.create_all(engine)
        print(f"Tabel '{TABLE_NAME}' berhasil dibuat.")
    else:
        print(f"Tabel '{TABLE_NAME}' sudah ada.")
        # Di lingkungan Docker, biasanya kita ingin script berjalan sekali dan selesai.
        # Jika tabel sudah ada, mungkin kita tidak perlu insert lagi, atau perlu clear dulu.
        # Untuk contoh ini, kita akan tetap mencoba insert (akan gagal jika ada primary key conflict)
        # atau Anda bisa uncomment bagian 'clear table' dari script sebelumnya jika diinginkan.

except SQLAlchemyError as e:
    print(f"Error saat memeriksa/membuat tabel '{TABLE_NAME}': {e}")
    sys.exit(1)
except Exception as e:
    print(f"Error tak terduga saat pengecekan/pembuatan tabel: {e}")
    sys.exit(1)

# --- Read and Prepare CSV Data ---
try:
    # Path di dalam container akan sama karena kita mount volume
    df = pd.read_csv(CSV_FILE_PATH)
    print(f"Berhasil membaca {len(df)} baris dari '{CSV_FILE_PATH}'.")
    df = df.where(pd.notnull(df), None)
    data_to_insert = df.to_dict(orient='records')

except FileNotFoundError:
    print(f"Error: File CSV tidak ditemukan di '{CSV_FILE_PATH}' di dalam container.")
    sys.exit(1)
except pd.errors.EmptyDataError:
     print(f"Error: File CSV '{CSV_FILE_PATH}' kosong.")
     sys.exit(1)
except Exception as e:
    print(f"Terjadi error saat membaca atau memproses CSV: {e}")
    sys.exit(1)


# --- Insert Data into Database ---
if data_to_insert:
    try:
        with engine.connect() as connection:
            with connection.begin():
                # Cek apakah data sudah ada berdasarkan Place_Id sebelum insert
                # Ini cara sederhana, untuk data besar mungkin perlu strategi lain
                existing_ids = set(connection.execute(f"SELECT Place_Id FROM {TABLE_NAME}").scalars())
                new_data = [row for row in data_to_insert if row['Place_Id'] not in existing_ids]

                if new_data:
                    connection.execute(places_table.insert(), new_data)
                    print(f"Berhasil memasukkan {len(new_data)} baris baru ke '{TABLE_NAME}'.")
                else:
                    print("Tidak ada data baru untuk dimasukkan (berdasarkan Place_Id).")

            print("Migrasi selesai!")

    except SQLAlchemyError as e:
        print(f"\n--- DATABASE INSERTION ERROR ---")
        print(f"Terjadi error saat memasukkan data: {e}")
        print("Periksa koneksi database, skema tabel, dan tipe data.")
        sys.exit(1)
    except Exception as e:
        print(f"Error tak terduga saat memasukkan data: {e}")
        sys.exit(1)
else:
    print("Tidak ada data dari CSV untuk dimasukkan.")