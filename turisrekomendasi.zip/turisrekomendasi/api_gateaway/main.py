from fastapi import FastAPI
import requests
from pydantic import BaseModel

app = FastAPI()

# Ubah URL sesuai dengan nama service di docker-compose
RECOMMENDATION_SERVICE_URL = "localhost:8000"

class RecommendationRequest(BaseModel):
    user_id: int
    num_recommendations: int = 5

class InteractionLog(BaseModel):
    user_id: int
    place_id: int
    action: str

@app.get("/")
def home():
    return {"message": "Welcome to Wisata Nusantara API Gateway!"}

@app.post("/recommendations")
def get_recommendations(request: RecommendationRequest):
    response = requests.post(f"{RECOMMENDATION_SERVICE_URL}/recommend", json=request.dict())
    return response.json()

@app.post("/interactions")
def log_interactions(interaction: InteractionLog):
    response = requests.post(f"{RECOMMENDATION_SERVICE_URL}/interactions", json=interaction.dict())
    return response.json()
